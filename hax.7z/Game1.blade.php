<!DOCTYPE html>
<html lang="en">

    <head>
        <title>CASH.LOL</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
        <meta charset="UTF-8">
        <link href="{{ asset('/css/game1.css') }}" rel="stylesheet">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">		
	</head>
    <body>
            @extends('layouts.app')
            @section('content')
            <div>
                <h1 class="Top" align="center">CASH.LOL</h1></div>
        <div class="container">
		<div class="row">
	    <div class="col-lg-3">
        <h2 class="Box" align="center"><a href="http://casino.test/games" style="color:black">GAMES</a></h2>
        <h2 class="Box" align="center"><a href="http://casino.test/deposit" style="color:black">DEPOSIT</a></h2>
        <h2 class="Box" align="center"><a href="http://casino.test/stats" style="color:black">STATISTICS</a></h2>
        <h2 class="Box" align="center"><a href="http://casino.test/" style="color:black">LOG IN</a></h2>
</div>	
		<div class="col-lg-6">
    <div><p class="Text">50/50</p></div>
        <p class="Text2">This is a game, in which you have a 50/50 chance of winning or losing. May luck be on your side</p>
        <p class="Text2">Which one is the right one?</p>
        
        <p style="font-size:20px">How much will you bet:
        <input type="text" id="Input" name="Bet" placeholder="Number"></p>
    
        <p class="Button"><button onclick="getRandom1()" type="button" class="Red" id="Game1">IS IT RED?</button></p>
        <script>

              function getRandom1() {
                var i = document.getElementById("Input").value;
                    if(i == ""){
                        document.getElementById("text").innerHTML = "Please input an amount, before choosing";
                        document.getElementById("text").className = "Error";
                    }if(i != parseInt(i, 10)){
                        document.getElementById("text").innerHTML = "Please input a number";
                        document.getElementById("text").className = "Error";
                    }if(i <= 0 ){
                        document.getElementById("text").innerHTML = "Please input a valid amount";
                        document.getElementById("text").className = "Error";   
                     
                }
                else{    
                            var x = (document.getElementById("Game1").innerHTML = Math.floor(Math.random() * 11));
                            document.getElementById("Game1").remove();
                            document.getElementById("Game2").remove();
                                if(x>5){
                                    document.getElementById("text").innerHTML = "You won: " +i + " EURO";
                                    document.getElementById("text").className = "Spawn";
                                } else{
                                    document.getElementById("text").innerHTML = "You lost: " +i + " EURO";
                                    document.getElementById("text").className = "Spawn";
                                }
                        }  
              }     
 
                        
        </script>
  

        <p class="Button"><button onclick="getRandom2()" type="button" class="Black" id='Game2'>IS IT BLACK?</button></p>
        <script>
            
            function getRandom2() {
                var i = document.getElementById("Input").value;
                if(i == ""){
                    document.getElementById("text").innerHTML = "Please input an amount, before choosing";
                    document.getElementById("text").className = "Error";
                }
                if(i != parseInt(i, 10)){
                    document.getElementById("text").innerHTML = "Please input a number";
                    document.getElementById("text").className = "Error";
                }if(i <= 0 ){
                    document.getElementById("text").innerHTML = "Please input a valid amount";
                    document.getElementById("text").className = "Error";
                }
                else{    
                var x = (document.getElementById("Game2").innerHTML = Math.floor(Math.random() * 11));
                document.getElementById("Game1").remove();
                document.getElementById("Game2").remove();
                    if(x<=5){
                        var i = document.getElementById("Input").value;
                        document.getElementById("text").innerHTML = "You won: " +i + " EURO";
                        document.getElementById("text").className = "Spawn";
                    } else{
                        var i = document.getElementById("Input").value;
                        document.getElementById("text").innerHTML = "You lost: " +i + " EURO";
                        document.getElementById("text").className = "Spawn";
                    }
              }
            }
        </script>

        <p id="text"></p>
        <input id="reset" type="button" value="Reset" class="Reset" onClick="window.location.reload()">
        <button onclick="show()" type="button" class='Admin' id="Admin">Answer</button>


        <script>
            function show(){
                var k = (document.getElementById("random").innerHTML = Math.random() * 3);
                if(k>1){
                ok = 1;
                document.getElementById("random").innerHTML = "Red";
                }else{
                ok = 2;
                document.getElementById("random").innerHTML = "Black";   
                }
            }
        </script>  
        <p id="random"></p>  
        </div>
<div class="col-lg-3">
		<h4 class="Statistics">World Wide Statistics</h4><h2 align="center">
            <div class="Box2">
            <h5 class="Stats">50/50 STATS</h5>
            <p class="p">TOTAL PLAYED: </p>
            <p class="p">TOTAL WON: </p>
            <p class="p">TOTAL LOST: </p>
            <h5 class="Stats">DICE STATS</h5>
            <p class="p">TOTAL PLAYED: </p>
            <p class="p">TOTAL WON: </p>
            <p class="p">TOTAL LOST: </p>
        </div>
        </h2>
</div>	

</div>
</div>
    </div>
    @endsection
</body>
</html>