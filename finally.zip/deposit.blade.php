<!DOCTYPE html>
<html lang="en">
    <head>
        <title>CASH.LOL</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
        <link href="css/css.css" rel="stylesheet"> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">		
	</head>
    <body>
    @extends('layouts.app')
    @section('content')
    <script type="text/javascript" src="js/javascript.js"></script>
    <div>
    <div class="links">
                    <a href="locale/en">English</a>
                    <a href="locale/pt">Portuguese</a>
                    <a href="locale/de">German</a>
                    <a href="locale/fr">French</a>
                    <a href="locale/ru">Russian</a>
                
                </div>
        <h1 class="Top" style="text-align:center;">CASH.LOL</h1></div>
        <div class="container">
		<div class="row">
        <div class="col-lg-3">
                <h2 class="Box" style="text-align:center;"><a href="http://casino.test/games" style="color:black">@lang('home.games')</a></h2>
                <h2 class="Boxnow" style="text-align:center;"><a href="http://casino.test/deposit" style="color:black">@lang('home.deposit')</a></h2>
                <h2 class="Box" style="text-align:center;"><a href="http://casino.test/stats" style="color:black">@lang('home.stats')</a></h2>
                <h2 class="Box" style="text-align:center;"><a href="http://casino.test/about" style="color:black">@lang('home.about')</a></h2>
            </div>		
		<div class="col-lg-6">
        @if(Auth::guest())
		    <div>
                <p class="login">@lang('home.gloginD')</p>
                </div>
                <div class="col-lg-6"></div>  
            @endif
    @if(!Auth::guest())
            <form action="{{route('submit')}}" method="post" id="deposit-form"><b>
                <h1>@lang('home.HdepositB')</h1>
                @lang('home.HmonD')<br>
                <input type="text" name="deposit"><br>
                {{csrf_field()}}
                <button type="submit"> @lang('home.Hdeposit')</button>
                <h1>@lang('home.HwhitdrawB')</h1>
                @lang('home.HmonW')<br>
                <input type="text" name="withdrawal"><br>
                <button type="button">@lang('home.Hwhitdraw')</button>
            </form></b>@endif
        </div>
        <div class="col-lg-3">
            <h4 class="Statistics">@lang('home.wstats')</h4>
            <div style="text-align:center;"><div class="Box2">
                <h5 class="Stats">50/50 @lang('home.stats')</h5>
                    <div class="p"><div style="float: left;">@lang('home.twon')</div><div id="totalwon">
                    <?php $casino = mysqli_connect("localhost", "Admin", "RELIoXM63bPZSex5", "casino");
                    $win1 = $casino->query("SELECT total_win FROM game WHERE id = 1")->fetch_object()->total_win;echo $win1;?></div> </div>
                    <div class="p"><div style="float: left;">@lang('home.tloss')  </div><div id="totallost">
                    <?php $loss1 = $casino->query("SELECT total_loss FROM game WHERE id = 1")->fetch_object()->total_loss;echo $loss1;?></div> </div>
                    <div class="p"><div style="float: left;">@lang('home.tplayed')</div><div id="totalplayed">
                    <?php $sum=0;$sum=$win1+$loss1;echo $sum;?>
                    <h5 class="Stats">DICE @lang('home.stats')</h5>
                    <div class="p"><div style="float: left;">@lang('home.tplayed') </div><div id="totalplayed2">
                    <?php $win2 = $casino->query("SELECT total_win FROM game WHERE id = 2")->fetch_object()->total_win;echo $win2;?></div> </div>
                    <div class="p"><div style="float: left;">@lang('home.twon') </div><div id="totalwon2">
                    <?php $loss2 = $casino->query("SELECT total_loss FROM game WHERE id = 2")->fetch_object()->total_loss;echo $loss2;?></div> </div>
                    <div class="p"><div style="float: left;">@lang('home.tloss')  </div><div id="totallost2">
                    <?php $sum=0;$sum=$win2+$loss2;echo $sum;?></div> </div>
            </div></div>
        </div>	

        </div>
        </div>
    @endsection
</body>
</html>