<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'Pages@index');

Route::get('/games', 'Pages@games');

Route::get('/deposit', 'Pages@deposit');

Route::get('/stats', 'Pages@stats');

Route::get('/about', 'Pages@about');

Route::get('/game1', 'Pages@Game1');

Route::get('/game2', 'Pages@Game2');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('auth/{driver}', ['as' => 'socialAuth', 'uses' => 'Auth\SocialController@redirectToProvider']);

Route::get('auth/{driver}/callback', ['as' => 'socialAuthCallback', 'uses' => 'Auth\SocialController@handleProviderCallback']);

Route::get('locale', function () {
    return \App::getLocale();
});

Route::get('locale/{locale}', function ($locale) {
    \Session::put('locale', $locale);
    return redirect()->back();
});
	
Route::post('/deposit',['as'=> 'submit', 'uses' => 'InsertController@insert']);