<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
class InsertController extends Controller {

public function insert(Request $request){
$deposit = $request->input('deposit');
$data=array('amount'=>0,'deposit'=>$deposit,'withdrawn'=>0,'user_id'=>5);
DB::table('cash')->insert($data);
echo "Record inserted successfully.<br/>";
echo '<a href = "/insert">Click Here</a> to go back.';
}
}